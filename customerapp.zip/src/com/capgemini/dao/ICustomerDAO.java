package com.capgemini.dao;
import com.capgemini.bean.Customerbean;
import com.capgemini.exception.CustomersException;
public interface ICustomerDAO {
	public String addCustomerDetails(Customerbean customerbean) throws CustomersException;
}





