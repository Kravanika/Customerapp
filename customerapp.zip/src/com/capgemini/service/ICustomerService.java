package com.capgemini.service;

import com.capgemini.bean.Customerbean;
import com.capgemini.exception.CustomersException;


public interface ICustomerService {
	public String addCustomerDetails(Customerbean customerbean) throws CustomersException;
}
