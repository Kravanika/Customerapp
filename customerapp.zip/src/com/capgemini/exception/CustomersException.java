package com.capgemini.exception;

public class CustomersException extends Exception {
private static final long serialVersionUID = 726264577455921591L;
	public CustomersException(String message) 
	{
		
		super(message);
	}

}
